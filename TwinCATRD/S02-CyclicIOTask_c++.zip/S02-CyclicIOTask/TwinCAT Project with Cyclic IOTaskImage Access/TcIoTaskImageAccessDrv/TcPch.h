///////////////////////////////////////////////////////////////////////////////
// TcPch.h includes TwinCAT standard header files, 
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#include "TcDef.h"
#include "TcBase.h"
#include "TcError.h"
#include "OsBase.h"
