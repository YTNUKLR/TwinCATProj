///////////////////////////////////////////////////////////////////////////////
// TcIoTaskImageAccessDrv.h

#pragma once

#include "ObjClassFactory.h"

class CTcIoTaskImageAccessDrvClassFactory : public CObjClassFactory
{
public:
	CTcIoTaskImageAccessDrvClassFactory();
	DECLARE_CLASS_MAP()
};


